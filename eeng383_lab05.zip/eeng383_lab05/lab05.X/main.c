//--------------------------------------------------------------------
// Name:            Chris Coulston
// Date:            Fall 2020
// Purp:            inLab05
//
// Assisted:        The entire class of EENG 383
// Assisted by:     Microchips 18F26K22 Tech Docs 
//-
//- Academic Integrity Statement: I certify that, while others may have
//- assisted me in brain storming, debugging and validating this program,
//- the program itself is my own work. I understand that submitting code
//- which is the work of other individuals is a violation of the course
//- Academic Integrity Policy and may result in a zero credit for the
//- assignment, or course failure and a report to the Academic Dishonesty
//- Board. I also understand that if I knowingly give my original work to
//- another individual that it could also result in a zero credit for the
//- assignment, or course failure and a report to the Academic Dishonesty
//- Board.
//------------------------------------------------------------------------
#include "mcc_generated_files/mcc.h"
#include <inttypes.h>
#pragma warning disable 520     // warning: (520) function "xyz" is never called  
#pragma warning disable 1498    // fputc.c:16:: warning: (1498) pointer (unknown)

#define DUTY_INC    1
#define NUM_COLOR   3
#define MILLISECOND 16000 // 1:1 prescaler counts
#define INTERVAL    3200 // 1:1 prescaler counts in .2 ms

uint16_t tmr0Period = MILLISECOND;
uint8_t dutyValueRed = 255; 
uint8_t dutyValueGreen = 255; 
uint8_t dutyValueBlue = 255; 

uint8_t globalTour = false;
uint8_t colorIndex = 0;

#if NUM_COLOR == 6
uint16_t initRed[NUM_COLOR] =  {0x00, 0x00, 0xFF, 0xFF, 0xFF, 0x00}; 
uint16_t initGreen[NUM_COLOR] = {0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00}; 
uint16_t initBlue[NUM_COLOR] = {0xFF, 0x00, 0x00, 0x00, 0xFF, 0xFF}; 

uint16_t deltaRed[NUM_COLOR] = {0x0000, 0x0000, 0x0001, 0x0000, 0x0000, 0xFFFF};
uint16_t deltaGreen[NUM_COLOR] = {0x0001, 0x0000, 0x0000, 0xFFFF, 0x0000, 0x0000};
uint16_t deltaBlue[NUM_COLOR] = {0x0000, 0xFFFF, 0x0000, 0x0000, 0x0001, 0x0000};
#error "Build fail"
#elif NUM_COLOR == 3
uint16_t initRed[NUM_COLOR] =  {0x00, 0xFF, 0x00}; 
uint16_t initGreen[NUM_COLOR] = {0xFF, 0x00, 0x00}; 
uint16_t initBlue[NUM_COLOR] = {0x00, 0x00, 0xFF}; 

uint16_t deltaRed[NUM_COLOR] = {0x0000, 0x0001, 0xFFFF};
uint16_t deltaGreen[NUM_COLOR] = {0x0001, 0xFFFF, 0x0000};
uint16_t deltaBlue[NUM_COLOR] = {0xFFFF, 0x0000, 0x0001};
#endif

void myTMR0ISR(void);
void printAscii();

//----------------------------------------------
// Main "function"
//----------------------------------------------

void main(void) {
    uint8_t i;
    char cmd; 
    
    SYSTEM_Initialize();
    
    EPWM3_LoadDutyValue(dutyValueRed);
    EPWM2_LoadDutyValue(dutyValueGreen);
    EPWM1_LoadDutyValue(dutyValueBlue);
    
    // Not necessary, but this delay allows the baud rate generator to 
    // stabilize before printing the splash screen on reset. If you are going to
    // do this, then make sure to put delay BEFORE enabling TMR interrupt.
    TMR0_WriteTimer(0x0000);
    INTCONbits.TMR0IF = 0;
    while(INTCONbits.TMR0IF == 0);
    
    TMR0_SetInterruptHandler(myTMR0ISR);
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();  
    
    printAscii();
    printf("Lab 05\r\n");
    printf("Color Cube\r\n");
    printf("Dev'21 board wiring\r\n");
    printf("B5 <-> Red LED\r\n");
    printf("C1 <-> Green LED\r\n");
    printf("C2 <-> Blue LED\r\n");
    
    for (;;) {
        printf("> ");
        while (!EUSART1_DataReady); // wait for incoming data on USART
        cmd = EUSART1_Read();
        printf("%c\r\n", cmd); // print the character that was received
        switch (cmd) { // and do what it tells you to do
            case '?':
                printf("------------------------------\r\n");
                printf("    Red:   0x%0.2x\r\n", CCPR3L);
                printf("    Green: 0x%0.2x\r\n", CCPR2L);
                printf("    Blue:  0x%0.2x\r\n", CCPR1L);
                printf("------------------------------\r\n");
                printf("?: Help menu\r\n");
                printf("Z: Reset processor\r\n");
                printf("z: Clear the terminal\r\n");
                printf("R/r: increase/decrease Red intensity\r\n");
                printf("G/g: increase/decrease Green intensity\r\n");
                printf("B/b: increase/decrease Blue intensity\r\n");
                printf("C/c: start/stop color cycle\r\n");
                printf("a: All LEDs off\r\n");
                printf("+/-: increase/decrease the color tour speed.\r\n");
                printf("------------------------------\r\n");
                break;

            case 'C': 
                globalTour = true; 
                colorIndex = NUM_COLOR - 1;
                dutyValueRed = initRed[colorIndex];
                dutyValueGreen = initGreen[colorIndex];
                dutyValueBlue = initBlue[colorIndex];
                colorIndex = 0;
                break; 

            case 'c': 
                globalTour = false; 
                dutyValueRed = 255;
                dutyValueGreen = 255;
                dutyValueBlue = 255;
                EPWM3_LoadDutyValue(dutyValueRed);
                EPWM2_LoadDutyValue(dutyValueGreen);
                EPWM1_LoadDutyValue(dutyValueBlue);
                break; 

            case 'R': //3
                if (dutyValueRed > 0) { 
                    dutyValueRed -= DUTY_INC;  
                    EPWM3_LoadDutyValue(dutyValueRed);
                }
                break; 

            case 'B': //1
                if (dutyValueBlue > 0 ) { 
                    dutyValueBlue -= DUTY_INC;  
                    EPWM1_LoadDutyValue(dutyValueBlue);
                }
                break; 

            case 'G': //4 
                 if (dutyValueGreen > 0 ) { 
                    dutyValueGreen -= DUTY_INC;  
                    EPWM2_LoadDutyValue(dutyValueGreen);
                }
                break; 

            case 'r': //3
                if( dutyValueRed < 255) { 
                    dutyValueRed += DUTY_INC;  
                    EPWM3_LoadDutyValue(dutyValueRed);
                }
                break; 

            case 'b': //1
                if (dutyValueBlue < 255) { 
                    dutyValueBlue += DUTY_INC;  
                    EPWM1_LoadDutyValue(dutyValueBlue);
                }
                break; 

            case 'g': //4 
                if ( dutyValueGreen < 255) { 
                    dutyValueGreen += DUTY_INC;  
                    EPWM2_LoadDutyValue(dutyValueGreen);
                }
                break;

            case '+':
                if (tmr0Period > INTERVAL) {
                    tmr0Period -= INTERVAL;
                }
                break;

            case '-':
                if (tmr0Period < 65535 - INTERVAL) {
                    tmr0Period += INTERVAL;
                }
                break;

            case 'a':
                globalTour = false;
                dutyValueRed = 255;
                dutyValueGreen = 255;
                dutyValueBlue = 255;

                EPWM3_LoadDutyValue(dutyValueRed);
                EPWM2_LoadDutyValue(dutyValueGreen);
                EPWM1_LoadDutyValue(dutyValueBlue);
                break;

                //--------------------------------------------
                // Reset the processor after clearing the terminal
                //--------------------------------------------
            case 'Z':
                for (i = 0; i < 40; i++) printf("\n");
                RESET();
                break;

                //--------------------------------------------
                // Clear the terminal
                //--------------------------------------------                      
            case 'z':
                for (i = 0; i < 40; i++) printf("\n");
                break;

                //--------------------------------------------
                // If something unknown is hit, tell user
                //--------------------------------------------
            default:
                printf("Unknown key %c\r\n", cmd);
                break;
        } // end switch
    } // end while 
} // end main

void myTMR0ISR(void)
{
    if (globalTour == true) {
        TMR0_WriteTimer(0x10000 - tmr0Period);
        uint16_t targetRed = initRed[colorIndex];
        uint16_t targetGreen = initGreen[colorIndex];
        uint16_t targetBlue = initBlue[colorIndex];
        if (dutyValueRed == targetRed 
                && dutyValueGreen == targetGreen
                && dutyValueBlue == targetBlue) {
            colorIndex++;
            if (colorIndex >= NUM_COLOR)
                colorIndex = 0;
        } else {
            dutyValueRed += deltaRed[colorIndex];
            dutyValueGreen += deltaGreen[colorIndex];
            dutyValueBlue += deltaBlue[colorIndex];
            
            EPWM3_LoadDutyValue(dutyValueRed);
            EPWM2_LoadDutyValue(dutyValueGreen);
            EPWM1_LoadDutyValue(dutyValueBlue);
        }
    }
}

void printAscii() {
    printf("                                                                                \r\n");
    printf("                                  777777777777                                  \r\n");
    printf("                            7777IIIIIIIIIIIIII?I7777                            \r\n");
    printf("                        777IIII77777777777777777IIIII777                        \r\n");
    printf("                     77III7777IIIIIII?????IIIIIII7777II?777                     \r\n");
    printf("                  77III777III???+++++++++++++++???III7777I?777                  \r\n");
    printf("                77II777II???++++++++++++++++++++++++??II777III77                \r\n");
    printf("              77II777II?+++++++++++++++++++++++++++++++??II77III77              \r\n");
    printf("             7II77II??+++++++++++++++++++++++++++++++++++??II77I?77             \r\n");
    printf("           77II77I??++++++++++++++++++++++++++++++++++++++++?II77II77           \r\n");
    printf("          77I77II?+++++++++++++++++++++++++++++++++++++++++++??I77I?77          \r\n");
    printf("         7?I7II?+++++++++++++++++++++++++++++++++++++++++++++++?II7III7         \r\n");
    printf("        7?I7II?+++++++++++++++++++++++++++++++++++++++++++++++++?II7III7        \r\n");
    printf("       7?III??++++++++++++++++++++++++++++++++++++++++++++++++++++?I7III7       \r\n");
    printf("      7IIII?++=...........+++++++++++++++++++++++++++:..........=++?III?77      \r\n");
    printf("     77I+=~.........................:+++++~.........................:=+I?77     \r\n");
    printf("     7?I=~,.........................................................,~=III7     \r\n");
    printf("    7III~,...........................................................,~II?77    \r\n");
    printf("    7?II?+...........................................................+?III?7    \r\n");
    printf("   77?II?+...........................+++++...........................+??II?77   \r\n");
    printf("   7?II?+++..........................+++++..........................~++?II?I7   \r\n");
    printf("   7?I??+++.........................+++++++.........................+++??I??7   \r\n");
    printf("  77????+++~........................+++++++.........................++++???+77  \r\n");
    printf("  77???+++++.......................+++++++++.......................+++++????77  \r\n");
    printf("  7I???++++++.....................=++++++++++.....................++++++????I7  \r\n");
    printf("  7I???++++++=...................~++++++++++++....................++++++???+I7  \r\n");
    printf("  7I+?+++++++++.................+++++++++++++++.................+++++++++?+?I7  \r\n");
    printf("  77+++++++++++++............=++++++++++++++++++++............++++++++++++++77  \r\n");
    printf("   7+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?7   \r\n");
    printf("   7+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++?7   \r\n");
    printf("   7I+++++++++++++..+++++++++++++++++++++++++++++++++++++++..+++++++++++=++I7   \r\n");
    printf("   77+==++++++++++,..+++++++++++++++++++++++++++++++++++++...++++++++++===?77   \r\n");
    printf("    7?===++++++++++...+++++++++++++++++++++++++++++++++++...++++++++++===+I7    \r\n");
    printf("    77=~~=++++++++++...+++++++++++++++++++++++++++++++++...++++++++++=~~=?77    \r\n");
    printf("     7I~~~=++++++++++:...+++++++++++++++++++++++++++++~...++++++++++=~~~+I7     \r\n");
    printf("      7?~:~=+++++++++++...+++++++++++++++++++++++++++...+++++++++++=~:~+I7      \r\n");
    printf("      77=:::=++++++++++++....+++++++++++++++++++++=...~+++++++++++=~::=?77      \r\n");
    printf("       77=:,:=+++++++++++++.....+++++++++++++++.....+++++++++++++=:::~?77       \r\n");
    printf("        77=:,:~++++++++++++++=...................:++++++++++++++~:,:~?77        \r\n");
    printf("         77?:,,:=+++++++++++++++++...........+++++++++++++++++=~,,:+?77         \r\n");
    printf("           7I~,,,~=++++++++++++++++++++++++++++++++++++++++++~:,,:+I7           \r\n");
    printf("            77?:,,:~=++++++++++++++++++++++++++++++++++++++~:,,:+?77            \r\n");
    printf("             77I~:,,:~=+++++++++++++++++++++++++++++++++=~:,,:~+I77             \r\n");
    printf("               77I~:,,,:~=+++++++++++++++++++++++++++=~:,,,:~+I77               \r\n");
    printf("                 77I?:,,,,:~==+++++++++++++++++++==~:,,,,:+?I77                 \r\n");
    printf("                   777?=::,,,,::~~===========~~:::,,,::~+?777                   \r\n");
    printf("                      777I?~:::,,,,,,,:,,,,,,,,,:::~+?I777                      \r\n");
    printf("                         7777I??+~~~::::::~~~~++??I7777                         \r\n");
    printf("                              777777IIIIIIII777777                              \r\n");
    printf("                                                                                \r\n");
    printf("                                                                                \r\n");
}
